#include <mpi.h>
#include <stdio.h>
#include "arr2str.c"


void my_gather(int* sendbuf, int len, int* recvbuf, int root) {
	int rank;
	int size;

	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&size);

	//Let's assume that the root is rank 0, and abort otherwise. 
	if (root!=0){
		fprintf(stderr,"Error, my_gather is only written for the case when the root is rank 0.\n");
		MPI_Abort(MPI_COMM_WORLD,1);
	}


  //Let's assume that the number of processors in existance is a power of 2, and
  //quit otherwise. 
}
