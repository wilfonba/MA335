double g(double x){
  return x*x;
}
