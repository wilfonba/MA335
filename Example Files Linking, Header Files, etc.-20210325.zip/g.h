double g(double x);
