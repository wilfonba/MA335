#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
  double x=1.45;

  printf("%lf^2=%lf\n",x,pow(x,2));
  return 0;
}
